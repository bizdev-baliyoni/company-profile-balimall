<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="/assets/images/logo.ico"
    />

    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="./assets/css/main.css" />

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />

    <title>Produk Kami</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow fixed-top">
      <div class="container ps-md-5 pe-md-5">
        <a class="navbar-brand ps-md-5" href="index.php">
          <div class="d-flex">
            <img src="./assets/images/logo-balimall.png" width="150px" alt="" />
            <!-- <div class="d-flex flex-column">
                        <p class="pt-2 bold mb-0">Ar<span class="text-danger">T</span>rade</p>
                        <small class="text-danger bold" style="font-size: 14px;">Smart Solution</small>
                    </div> -->
          </div>
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse pe-md-5 align-items-center"
          id="navbarSupportedContent"
        >
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0 pt-4 pb-4">
            <li class="nav-item pe-md-4">
              <a class="nav-link" aria-current="page" href="index.php">Tentang Kami</a>
            </li>
            <li class="nav-item pe-md-4">
              <a class="nav-link active" href="#">Produk Kami</a>
            </li>
            <li class="nav-item pe-md-4">
              <a class="nav-link" href="partnership.php">Kerjasama</a>
            </li>
            <li class="nav-item pe-md-4">
              <a class="nav-link" href="contact.php">Kontak</a>
            </li>
            <!-- <li class="nav-item pe-md-4 px-2">
                        <div class="dropdown" id="button_language">
                            <button class="btn dropdown-toggle language-toggle" onclick="changedropdown()" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                              <figure>
                                <img src="./assets/images/language.svg" class="filter-svg" alt="">
                              </figure>
                            </button>
                            <div class="dropdown-menu link-language" id="dropdown_language" aria-labelledby="dropdownMenuButton">
                                <figure onclick="changeLanguage('ind')" class="mx-2">
                                    <img src="./assets/images/indo_flag.png" alt="">
                                </figure>
                                <figure onclick="changeLanguage('eng')">
                                    <img src="./assets/images/usa_flag.png" class="mx-2" alt="">
                                </figure>
                            </div>
                          </div>
                    </li> -->
          </ul>
        </div>
      </div>
    </nav>

    <div id="IndView">
      <!-- content -->
      <!-- title -->
      <section class="bg-dark text-light py-0">
        <div class="container ps-md-5 pe-md-5 pt-5">
          <div class="pt-5 ps-md-5 pe-md-5">
            <h1 class="bold pt-md-5" style="font-size: 50pt">Produk Kami</h1>
            <br />
          </div>
        </div>
      </section>
      <!-- end title -->

      <!-- Ekosistem Balimall -->
      <section class="bg-body mt-2 mb-4">
        <div
          class="container ps-md-5 pe-md-5 pt-md-5"
          data-aos="fade-up"
          data-aos-delay="200"
        >
          <div class="row">
            <div class="col-md-4" data-aos="fade-right" data-aos-delay="300">
              <div class="card border-light shadow h-100">
                <div class="card-body">
                  <h4 class="bold text-danger mb-0 text-center">balimall.id</h4>
                  <br />
                  <p class="text-justify">
                    balimall.id merupakan platform <i>e-marketplace</i> sebagai salah satu solusi alternatif dalam hal transaksi
                    online, solusi terhadap permasalahan UMKM/ IKM Bali dan
                    solusi untuk penanganan pariwisata Bali demi percepatan
                    pemulihan ekonomi Bali yang Berdikari Secara Ekonomi, dan
                    Berkepribadian dalam Kebudayaan Melalui Pembangunan Secara
                    Terpola, Menyeluruh, Terencana, Terarah, dan Terintegrasi.
                  </p>
                </div>
                <a target="_blank" href="https://balimall.id/" class="btn btn-danger btn-md my-2 mx-5">Kunjungi Website</a>
              </div>
            </div>
            <div class="col-md-4" data-aos="fade-right" data-aos-delay="300">
              <div class="card border-light shadow h-100">
                <div class="card-body">
                  <h4 class="bold text-danger mb-0 text-center">
                    tokodaring.balimall.id
                  </h4>
                  <br />
                  <p class="text-justify">
                    tokodaring.balimall.id merupakan platform <i>e-marketplace</i> sebagai salah satu solusi <i>e-purchasing</i> pengadaan barang/jasa
                    pemerintah yang bekerjasama dengan PPMSE untuk meningkatkan
                    penggunaan Produk Dalam Negeri dan meningkatkan keterlibatan
                    UMK dalam pengadaan barang/jasa pemerintah melalui kanal Bela Pengadaan-Toko Daring E-Katalog LKPP.
                  </p>
                </div>
                <a target="_blank" href="https://tokodaring.balimall.id/" class="btn btn-danger btn-md my-2 mx-5">Kunjungi Website</a>
              </div>
            </div>
            <div class="col-md-4" data-aos="fade-right" data-aos-delay="300">
              <div class="card border-light shadow h-100">
                <div class="card-body">
                  <h4 class="bold text-danger mb-0 text-center">bisnis.balimall.id</h4>
                  <br />
                  <p class="text-justify">
                    bisnis.balimall.id merupakan <i>platform e-marketplace</i> untuk
                    memfasilitasi transaksi antara korporasi/perusahaan dengan pelaku usaha baik dalam skala kecil maupun skala besar, yang didukung
                    dengan metode pembayaran digital sistem pasca bayar, kemudahan transaksi, administrasi dan dokumen. 
                  </p>
                </div>
                <a target="_blank" href="https://bisnis.balimall.id/" class="btn btn-danger btn-md my-2 mx-5">Kunjungi Website</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- end Ekosistem Balimall -->

      <!-- end content -->
    </div>
    <div id="EngView">
      <!-- content -->
      <!-- title -->
      <section class="bg-dark text-light py-5">
        <div class="container ps-md-5 pe-md-5 pt-5">
          <div class="pt-5 ps-md-5 pe-md-5">
            <h1 class="bold pt-md-5" style="font-size: 50pt">Produk Kami Us</h1>
            <hr style="border: 5px solid #ed1c24; width: 200px" />
          </div>
        </div>
      </section>
      <!-- end title -->
      <!-- sejarah -->
      <section class="bg-body">
        <img
          src="./assets/images/banner-about.jpeg"
          class="d-none d-lg-block rounded-3 image-banner"
          alt=""
        />
        <img
          src="./assets/images/banner-about.jpeg"
          class="h-75 d-lg-none d-block w-100 rounded-3"
          alt=""
        />
        <div class="container ps-md-5 pe-md-5 pt-md-5">
          <div class="row pt-5 ps-md-5 pe-md-5">
            <div class="col-md-12">
              <div class="my-auto mt-0 mt-md-5">
                <h2
                  class="bold lh-lg"
                  data-aos="fade-left"
                  data-aos-delay="100"
                >
                  <span class="text-danger">History</span>
                </h2>
                <div class="col-md-6" data-aos="fade-left" data-aos-delay="100">
                  <p class="text-justify">
                    Arisma Teknika Mesari was born from an information
                    technology company that continued to grow until we finally
                    collaborated to create a company engaged in technology
                    consulting and financial consulting. Arisma Teknika Mesari
                    prioritizes security, convenience, speed and stable profits.
                    Arisma Teknika Mesari is present in Indonesia to educate
                    about the importance of proper asset management.
                  </p>
                </div>
                <h2
                  class="bold lh-lg"
                  data-aos="fade-left"
                  data-aos-delay="100"
                >
                  <span class="text-danger">Why</span>
                </h2>
                <div class="col-md-6" data-aos="fade-left" data-aos-delay="100">
                  <p class="text-justify">
                    We want to be a bridge for everyone to learn the world of
                    investment safely, easily, quickly and profitably.
                  </p>
                </div>
                <h2
                  class="bold lh-lg"
                  data-aos="fade-left"
                  data-aos-delay="100"
                >
                  <span class="text-danger">How</span>
                </h2>
                <div class="col-md-6" data-aos="fade-left" data-aos-delay="100">
                  <p class="text-justify">
                    Being serious in this business is our advantage, collecting
                    every data, doing in-depth research and implementing with
                    technology.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- end sejarah -->

      <!-- visi misi -->
      <!-- sejarah -->
      <section class="bg-body py-5">
        <div class="container ps-md-5 pe-md-5">
          <div
            class="row pt-5 ps-md-5 pe-md-5 flex-row-reverse"
            data-aos="fade-in"
            data-aos-delay="200"
          >
            <div class="col-md-6">
              <div class="ps-0 ps-md-5">
                <h2 class="bold lh-lg">
                  <span class="text-danger">Vision </span> and Mission of
                  <span class="bold"
                    >Ar<span class="text-danger">T</span>rade</span
                  >
                </h2>
                <div>
                  <ul class="list-unstyled">
                    <li class="d-flex">
                      <i
                        class="bi bi-arrow-right-circle text-danger"
                        style="margin-right: 1rem"
                      ></i
                      >To be the best company in the field of technology
                      consulting services as well as financial consulting.
                    </li>
                    <li class="d-flex">
                      <i
                        class="bi bi-arrow-right-circle text-danger"
                        style="margin-right: 1rem"
                      ></i
                      >Making people educated in the financial world, especially
                      trading and understand how financial governance.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="mx-auto" style="height: 450px">
                <img
                  class="w-100 rounded"
                  src="./assets/images/ic-mission.jpeg"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- end sejarah -->
      <!-- visi misi -->
      <!-- end content -->
    </div>

    <!-- footer -->
    <footer class="bg-light text-dark py-5">
      <div class="container mt-5 ps-md-5 pe-md-5">
        <div class="row ps-md-5 pe-md-5">
          <div class="col-md-4">
            <div class="mb-3" style="height: 100px">
              <div class="d-flex">
                <img
                  width="150px"
                  src="./assets/images/logo-balimall.png"
                  alt=""
                />
              </div>
              <div>
                <h5 class="pt-2 bold mb-0">
                  PT. <span class="text-danger">B</span>ali
                  <span class="text-danger">U</span>nggul
                  <span class="text-danger">S</span>ejahtera
                </h5>
              </div>
            </div>
            <div class="mt-2 w-100">
              <a
                href="https://www.instagram.com/balimall.id/"
                class="text-decoration-none"
              >
                <img src="./assets/images/logo-ig.png" alt="" />
              </a>
              <a
                href="https://www.facebook.com/Balimallid.Official/"
                class="text-decoration-none"
              >
                <img src="./assets/images/logo-fb.png" alt="" />
              </a>
            </div>
          </div>

          <div class="col-md-4 ps-md-5 mt-5 mt-md-0">
            <h2>Menu</h2>
            <ul class="list-unstyled list-group custom-footer">
              <li class="py-2">
                <a href="index.php">Tentang Kami</a>
              </li>
              <li class="py-2">
                <a href="product.php" class="active">Produk Kami</a>
              </li>
              <li class="py-2">
                <a href="partnership.php">Kerjasama</a>
              </li>
              <li class="py-2">
                <a href="contact.php">Kontak</a>
              </li>
            </ul>
          </div>

          <div class="col-md-4 mt-5 mt-md-0">
            <h2 class="pb-3">Office Location</h2>
            <div class="text-gray">
              <p class="lh-lg pb-3">
                Jl. Moh. Yamin IX No. 19 Denpasar <br />
                Jl. Tukad Batanghari 1A Denpasar
              </p>
              <p>
                <img src="./assets/images/ic-phone.png" alt="" />
                <a
                  class="text-decoration-none"
                  href="https://wa.me/6281131164999"
                >
                  +62 81131164999</a
                >
              </p>
              <span
                ><img src="./assets/images/ic-email.png" alt="" />
                <a class="text-decoration-none" href="mailto:info@balimall.id">
                  info@balimall.id</a
                ></span
              >
            </div>
          </div>
        </div>

        <p class="text-center mt-5 text-gray">
          © Copyright 2024 PT. Bali Unggul Sejahtera
        </p>
      </div>
    </footer>

    <!-- end footer -->

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
      var dataLanguage = localStorage.getItem("Language");
      var checkdropdown = false;
      if (dataLanguage === "ind") {
        document.getElementById("IndView").style.display = "block";
        document.getElementById("EngView").style.display = "none";
      } else if (dataLanguage === "eng") {
        document.getElementById("IndView").style.display = "none";
        document.getElementById("EngView").style.display = "block";
      } else {
        localStorage.setItem("Language", "ind");
        document.getElementById("IndView").style.display = "block";
        document.getElementById("EngView").style.display = "none";
      }
      function changedropdown() {
        if (!checkdropdown) {
          checkdropdown = true;
          document.getElementById("button_language").classList.add("show");
          document.getElementById("dropdown_language").classList.add("show");
        } else {
          checkdropdown = false;
          document.getElementById("button_language").classList.remove("show");
          document.getElementById("dropdown_language").classList.remove("show");
        }
      }
      function changeLanguage(data) {
        localStorage.setItem("Language", data);
        if (data === "ind") {
          document.getElementById("IndView").style.display = "block";
          document.getElementById("EngView").style.display = "none";
          checkdropdown = false;
          document.getElementById("button_language").classList.remove("show");
          document.getElementById("dropdown_language").classList.remove("show");
        } else if (data === "eng") {
          document.getElementById("IndView").style.display = "none";
          document.getElementById("EngView").style.display = "block";
          checkdropdown = false;
          document.getElementById("button_language").classList.remove("show");
          document.getElementById("dropdown_language").classList.remove("show");
        }
      }
      AOS.init();
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>
